VIKIT
-----

Vikit (Vision-Kit) provides some tools for your vision/robotics project.
Far from stable.

